from flask import Flask, render_template
from posrednik import Posrednik
import pandas as pd
import plotly.express as px
import visual
from threading import Thread

app = Flask('')

ticker_list = ['SBER', 'GAZP', 'OGKB', 'FIVE', 'NVTK', 'PIKK',
               'ROSN', 'IRAO', 'YNDX', 'VKCO', 'VTBR', 'MTLR']

@app.route('/')
def main():
    return "Your bot is alive!"

@app.route('/plots/<stock>')
def home(stock):
    if stock in ticker_list:
        graphJSON = visual.getplot_image(f"{stock}", f'./data/{stock}_data.csv', 250)
    else:
        return "Не найдено такой акции"
    return render_template('notdash.html', graphJSON=graphJSON, stock=stock)

def run():
    app.run(host="127.0.0.1", port=8080)
    print('Сайт запущен!')

def start():
    server = Thread(target=run)
    server.start()

if __name__ == "__main__":
    start()