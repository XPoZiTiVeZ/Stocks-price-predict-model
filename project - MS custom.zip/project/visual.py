import plotly.graph_objects as go
import numpy as np
import pandas as pd
from random import randint
import plotly
import plotly.io as pio
from io import BytesIO
import kaleido
import json
from model import get_round_num

def getplot(name: str, file: str, value: tuple, is_max_quality=False) -> None:
    '''
    Тупая функция для сохранения тупого графика, с которым я мучился 4 часа
    '''
    
    dataset_ful = pd.read_csv(file, index_col='TRADEDATE', parse_dates=['TRADEDATE']).dropna()
    dataset = dataset_ful[-30:]
    
    dataset_last = dataset_ful[-1:]
    dataset_last_next = dataset_last.index[0] + pd.Timedelta(days = 1)
    dataset_last_time = pd.DatetimeIndex((dataset_last.index[0], dataset_last_next))

    maxn = max(dataset['CLOSE'])
    minn = min(dataset['CLOSE'])
    mean = round((minn + maxn)/2, get_round_num(name))
    now = dataset['CLOSE'][-1]

    # графики:
    layout = go.Layout(plot_bgcolor='black')

    fig = go.Figure(layout = layout)

    fig.add_hline(y = maxn, line_color = 'green',
                annotation=dict(
                    text=f'Максимальная цена {maxn}',
                    align = 'right',
                    font = dict(color = 'green')
                ))

    fig.add_hline(y = mean, line_color='lightgrey',
                annotation=dict(
                    text=f'Средняя цена {mean}',
                    align='right',
                    font = dict(color = 'lightgrey')))

    fig.add_hline(y = minn, line_color='red',
                annotation=dict(
                    text=f'Минимальная цена {minn}',
                    align='right',
                    font = dict(color = 'red')))

    fig.add_hline(y = now, line_color='lightgreen',
                line_dash = 'dash',
                annotation=dict(
                    text=f'Цена сейчас {now}',
                    align='right',
                    font = dict(color = 'lightgreen')))

    fig.add_hline(y = value, line_color='orange',
                line_dash = 'dash',
                annotation=dict(
                    text=f'Предсказанная цена {value}',
                    align='right',
                    font = dict(color = 'orange')))

    fig.add_trace(go.Scatter(x = dataset.index,
                            y = dataset['CLOSE'],
                            mode = 'lines',
                            name = 'Реальная цена'))
                    
    fig.add_trace(go.Scatter(x = dataset_last_time,
                            y = [dataset_last['CLOSE'][0], value],
                            mode = 'lines',
                            name = 'Предсказанная цена'))

    # настройки:
    fig.update_layout(hovermode="x",
                    legend_orientation="v",
                    legend=dict(x=.5, xanchor="center"),
                    xaxis_tickformat = '%d %B<br>%Y',
                    margin=dict(l=10, r=10, t=30, b=10), width=900, height=1200)

    fig.update_traces(hoverinfo="all", hovertemplate='Цена: %{y}')
    fig.update_xaxes(griddash="dash")
    fig.update_yaxes(tick0 = 0, dtick = 50)
    # fig.show()
    # экспорт
    if is_max_quality:
        pio.write_image(fig, f'./mq_plots/MQ_{name}_plot.png', format='png', scale=9, width=1440, height=1920)
    else:
        pio.write_image(fig, f'./plots/{name}_plot.png', format='png', scale=2, width=1440, height=1920)
        

# getplot('SBE, 'D:\Documents\Python\stock predicting\SBER_data.csv', 250)

def getplot_image(name: str, file: str, value: tuple) -> json:
    '''
    Тупая функция для сохранения тупого графика, с которым я мучился 4 часа
    '''

    dataset_ful = pd.read_csv(file, index_col='TRADEDATE', parse_dates=['TRADEDATE']).dropna()
    dataset = dataset_ful[-30:]
    
    dataset_last = dataset_ful[-1:]
    dataset_last_next = dataset_last.index[0] + pd.Timedelta(days = 1)
    dataset_last_time = pd.DatetimeIndex((dataset_last.index[0], dataset_last_next))

    maxn = max(dataset['CLOSE'])
    minn = min(dataset['CLOSE'])
    mean = (minn + maxn)/2
    now = dataset['CLOSE'][-1]

    # графики:
    layout = go.Layout(plot_bgcolor='black')

    fig = go.Figure(layout = layout)

    fig.add_hline(y = maxn, line_color = 'green',
                annotation=dict(
                    text=f'Максимальная цена {maxn}',
                    align = 'right',
                    font = dict(color = 'green')
                ))

    fig.add_hline(y = mean, line_color='lightgrey',
                annotation=dict(
                    text=f'Средняя цена {mean}',
                    align='right',
                    font = dict(color = 'lightgrey')))

    fig.add_hline(y = minn, line_color='red',
                annotation=dict(
                    text=f'Минимальная цена {minn}',
                    align='right',
                    font = dict(color = 'red')))

    fig.add_hline(y = now, line_color='lightgreen',
                line_dash = 'dash',
                annotation=dict(
                    text=f'Цена сейчас {now}',
                    align='right',
                    font = dict(color = 'lightgreen')))

    fig.add_hline(y = value, line_color='orange',
                line_dash = 'dash',
                annotation=dict(
                    text=f'Предсказанная цена {value}',
                    align='right',
                    font = dict(color = 'orange')))

    fig.add_trace(go.Scatter(x = dataset.index,
                            y = dataset['CLOSE'],
                            mode = 'lines',
                            name = 'Реальная цена'))
    
    if value != -1:
        fig.add_trace(go.Scatter(x = dataset_last_time,
                                y = [dataset_last['CLOSE'][0], value],
                                mode = 'lines',
                                name = 'Предсказанная цена'))

    # настройки:
    fig.update_layout(hovermode="x",
            showlegend = False,
            xaxis_tickformat = '%d %B<br>%Y',
            margin=dict(l=10, r=10, t=30, b=10), height=800)

    fig.update_traces(hoverinfo="all", hovertemplate='Цена: %{y}')
    fig.update_xaxes(griddash="dash")
    fig.update_yaxes(tick0 = 0, dtick = 50)
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)